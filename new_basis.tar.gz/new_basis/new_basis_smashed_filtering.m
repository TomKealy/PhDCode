clear all;
close all;

M = 300;
K = [300, 280, 260, 240, 220, 200, 180, 160, 140, 120, 100];
runs = 10;
mse = zeros(size(K,2), runs);
for i=1:size(K,2)
    edges = [50, 120, 170, 192, 220, 224, 256, 300] ;
    levels = [0,  0 , 40000, 0, 0, 0, 0, 0];
    idxs = zeros(1, M)  ;
    idxs(edges(1: end-1)+1) = 1 ;
    g = levels(cumsum(idxs)+1);
    sigma_squared = [1, 10, 100, 1000];
    noise = normrnd(0, 1, [1, M]);
    max_not_in_positions = 0;
    g = g;% + noise;
    
    tic
    for j=1:runs
        %     positions = randi(M, [1, 5]);
        %     weights = normrnd(100, sigma_squared(j), [1, 5]);
        %
        %     g = zeros(1,M);
        %     g(positions) = weights;
        
        ge = g + noise;
        
        F = LehmerMatrix(M);
        [L U] = lu(F);
        I = eye(M);
        D = inv(L);
        
        h = cumsum(g)';
        
        he = cumsum(ge)';
        
        %h = Fa;
        
        A = normrnd(0, 1/(K(i)), [K(i), M]);
        
        B = diag(diag(A'*A));
        
        C = A'*A - B;
        
        AtA = A'*A;
        
        [U, S, V] = svd(A);
        
        G = V'*S'*S*V;
        
        snr(j) = norm(g)/norm(noise);
        
        y = A*g';
        
        eg = max(abs(eig((A)'*(A))));
        rho = nthroot(1/eg,3);
        lambda = sqrt(2*log(M));
        relaxation_parameter = 1.0;
        
        ops = struct('max_iter', {1000}, ...
            'quiet', {1}, ...
            'abs_tol', {1e-4}, ...
            'rel_tol', {1e-2}....
            );
        
        [ahat, history] = lasso_admm_1(A*L', y, lambda, rho, relaxation_parameter, ops);
        
        templates = zeros(M, K(i));
        b = zeros(1, M);
        c = zeros(1, M);
        
        [u, s, v] = svd(A);
        
        for k=1:M
            templates(k, :) = (A*A')\A*L(k,:)';
            b(k) = (M/K(i))*(y'*templates(k,:)');
        end
        
        mse(i,j) = norm(L\b' - g')/norm(g');
        
%         P = eye(K) - templates';
%         
%         out_filt = filter(L(1,:)', 1, b);
%         
%         [sortVals, sortInds] = sort(b, 'descend');
%         
%         figure
%         plot(1:M, b, 'b', 1:M, cumsum(L'*ahat), 'rx', 1:M, cumsum(g), 'go')
%         
%         figure
%         plot(L\b')
    end
    toc
end

