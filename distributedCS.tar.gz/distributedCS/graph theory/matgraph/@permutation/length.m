function s = length(p)
% length(p) gives the size of the permutation
s = length(p.array);