function yn = ne(p,q)
% ne(p,q) --- p ~= q checks if p and q are different
yn = ~(p==q);