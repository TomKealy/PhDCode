function i = slot(g)
% slot(g) --- slot number occupied by g in GRAPH_MAGIC

i = g.idx;