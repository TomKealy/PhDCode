function n = q_capacity
% q_capacity --- what is the maximum number of elements the queue can hold

global GRAPH_MAGIC

n = length(GRAPH_MAGIC.Q.array);