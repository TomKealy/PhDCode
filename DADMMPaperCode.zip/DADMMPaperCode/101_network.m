net = csvread('net_data1.csv');

